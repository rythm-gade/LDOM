package rit.ldom;

public interface Text extends Component {
}
